-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 04 Août 2015 à 09:54
-- Version du serveur: 5.1.36
-- Version de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bd_agas`
--

-- --------------------------------------------------------

--
-- Structure de la table `abonnement`
--

CREATE TABLE IF NOT EXISTS `abonnement` (
  `ID_ABONNEMENT` int(11) NOT NULL AUTO_INCREMENT,
  `TYPE_ABONNEMENT` varchar(20) CHARACTER SET utf8 NOT NULL,
  `MONTANT` int(20) NOT NULL,
  `CATEGORIE` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`ID_ABONNEMENT`),
  KEY `TYPE_ABONNEMENT` (`TYPE_ABONNEMENT`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Contenu de la table `abonnement`
--

INSERT INTO `abonnement` (`ID_ABONNEMENT`, `TYPE_ABONNEMENT`, `MONTANT`, `CATEGORIE`) VALUES
(1, 'Mensuel', 25000, 'Enfant'),
(2, 'Mensuel', 45000, 'Adulte'),
(3, 'Trimestriel', 35000, 'Enfant'),
(4, 'Trimestriel', 55000, 'Adulte'),
(5, 'Semestriel', 45000, 'Enfant'),
(6, 'Semestriel', 90000, 'Adulte'),
(7, 'Annuel', 60000, 'Enfant'),
(8, 'Annuel', 105000, 'Adulte');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `MATRICULE` int(11) NOT NULL,
  `RECU_ENTENTE` int(25) NOT NULL,
  `RECU_PISCINE` int(25) NOT NULL,
  `NOM` varchar(40) CHARACTER SET latin1 NOT NULL,
  `PRENOM` varchar(40) NOT NULL,
  `SEXE` varchar(15) NOT NULL,
  `EMAIL` varchar(50) CHARACTER SET latin1 NOT NULL,
  `NATIONALITE` varchar(15) CHARACTER SET latin1 NOT NULL,
  `DATE_NAISSANCE` date NOT NULL,
  `PHOTO` varchar(30) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`MATRICULE`),
  UNIQUE KEY `RECU_PISCINE` (`RECU_PISCINE`),
  UNIQUE KEY `RECU_ENTENTE` (`RECU_ENTENTE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `client`
--

INSERT INTO `client` (`MATRICULE`, `RECU_ENTENTE`, `RECU_PISCINE`, `NOM`, `PRENOM`, `SEXE`, `EMAIL`, `NATIONALITE`, `DATE_NAISSANCE`, `PHOTO`) VALUES
(2, 2, 2, 'Nyandwi', 'Viola', 'Feminin', 'wilyirak@gmail.fr', 'Burundais', '2002-01-04', 'arlene.jpg'),
(3, 3, 3, 'KAGABO', 'Jean', 'Masculin', 'wilyirak@gmail.fr', 'Burundais', '1998-01-06', '69933477_2-1429161609463.jpg'),
(4, 4, 4, 'NIHOZE', 'Benis Bokim', 'Masculin', 'bokimbeni@gmail.fr', 'Burundais', '1998-01-06', 'DSC05932.JPG'),
(5, 5, 5, 'Nzeyimana', 'Alexis', 'Masculin', 'pe@gmail.fr', 'Burundais', '1985-01-06', 'Alexis.png'),
(6, 6, 6, 'MANARIYO', 'Fiona', 'Feminin', 'wilyirak@gmail.fr', 'Burundais', '2000-01-13', '69933454_0-1429102045157.jpg'),
(7, 7, 7, 'NZEYIMANA', 'MARS', 'Masculin', 'ishi@yahoo.fr', 'Burundais', '1998-01-06', '6.jpg'),
(8, 8, 8, 'NZEYIMANA', 'Laura', 'Feminin', 'ishi@yahoo.COM', 'Burundais', '1998-01-06', '69933455_2-1429101539326.jpg'),
(9, 9, 9, 'NAHIMANA', 'Jean Paul', 'Masculin', 'HUJ@gmail.com', 'Burundais', '1998-01-06', 'Cliff.jpg'),
(11, 11, 11, 'NDUWAYEZU', 'Paul', 'Feminin', 'po@hotmail.com', 'Burundais', '1973-01-26', '4.jpg'),
(12, 134, 135, 'RUKUNDO', 'annick', 'Feminin', 'RUK@gmail.com', 'Burundais', '2005-03-10', '9.jpg'),
(13, 136, 137, 'KAUKA', 'anny', 'Feminin', 'kauk@gmail.com', 'Burundais', '2006-03-08', '69933496_2-1429109536510.jpg'),
(14, 14, 14, 'NDEREYIMANA', 'Peter', 'Feminin', 'pe@hotmail.com', 'Burundais', '1995-07-26', '2.jpg'),
(15, 15, 15, 'ISHIMWE', 'ArlÃ¨ne', 'Feminin', 'arlyishi@gmail.com', 'Burundais', '1991-07-26', 'IMG_5519.JPG'),
(16, 16, 16, 'NSHIMIRIMANA', 'Pierre', 'Feminin', 'arlyishi@gmail.com', 'Burundais', '1985-07-26', '10.jpg'),
(17, 17, 171, 'NSHIMIRIMANA', 'Pierre Jospin', 'Masculin', 'arlyishi@gmail.com', 'Burundais', '2004-07-26', '5.jpg'),
(18, 18, 182, 'UWIMANA', 'Josepha', 'Feminin', 'pha@gmail.com', 'Burundais', '2004-07-26', '11.PNG'),
(19, 19, 1998, 'NDAGIJIMANA', 'Sammuella', 'Feminin', 'samy@g.com', 'Burundais', '1990-02-05', '69933458_2-1429094522095.jpg'),
(21, 21, 21, 'MANIRAMBONA', 'Primes', 'Masculin', 'gg@gma.com', 'Burundais', '2000-02-05', '69693078_2-1429079910832.jpg'),
(35, 35, 35, 'NAHIMANA', 'Michelle', 'Feminin', 'miche@hotmail.com', 'Burundais', '1971-01-26', '1.jpg'),
(39, 129, 120, 'MPAWENIMANA', 'MARCUS', 'Masculin', 'marcus@hotmail.com', 'Burundais', '1995-07-26', '2.jpg'),
(135, 135, 1343, 'NAHIMANA', 'Mikel', 'Masculin', 'po@hotmail.com', 'Burundais', '2007-01-26', '5.jpg'),
(141, 1211, 213, 'IRAKOZE', 'Armand', 'Masculin', 'willyirak@yahoo.fr', 'Burundais', '2003-01-06', 'Armand.bmp'),
(145, 138, 139, 'RAIKA', 'Vinsy', 'Masculin', 'raik@gmail.com', 'Burundais', '2004-02-04', '69933504_2-1429103857508.jpg'),
(146, 147, 149, 'KANYANA', 'Alice', 'Feminin', 'kanali@gmail.com', 'Burundais', '2003-05-07', '3.jpg'),
(158, 159, 200, 'MAHORO', 'LUCK', 'Masculin', 'maho@gmail.com', 'Burundais', '2002-03-07', '10.jpg'),
(221, 241, 242, 'KAVAKURE', 'Claude', 'Masculin', 'kav@yahoo.fr', 'Burundais', '2000-02-09', '69933439_2-1429163656878.jpg'),
(234, 240, 241, 'YASIN', 'CARMEL', 'Masculin', 'yasi@yahoo.fr', 'Etranger', '2001-06-06', '69933431_2-1429166018864.jpg'),
(351, 351, 432, 'NTAKIRUTIMANA', 'MARS', 'Feminin', 'miche@hotmail.com', 'Burundais', '2003-01-26', '3.jpg'),
(3521, 123, 123, 'MPAWENIMANA', 'Gervais', 'Feminin', 'ge@hotmail.com', 'Burundais', '1995-01-26', 'WILLY.png'),
(22111, 12322, 212343, 'RUVUGO', 'Kenny', 'Masculin', 'kav@yahoo.fr', 'Burundais', '2001-02-07', '69040843_2-1428674305180.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

CREATE TABLE IF NOT EXISTS `employe` (
  `MATRICULE_EMPLOYE` int(11) NOT NULL,
  `NOM` varchar(25) CHARACTER SET latin1 NOT NULL,
  `PRENOM` varchar(25) CHARACTER SET latin1 NOT NULL,
  `QUALIFICATION` varchar(20) NOT NULL,
  `ADRESSE` varchar(20) NOT NULL,
  `TELEPHONE` varchar(15) NOT NULL,
  `SEXE` varchar(10) CHARACTER SET latin1 NOT NULL,
  `NATIONALITE` varchar(11) CHARACTER SET latin1 NOT NULL,
  `FONCTION` varchar(25) NOT NULL,
  `PHOTO` varchar(20) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`MATRICULE_EMPLOYE`),
  UNIQUE KEY `PHONE` (`TELEPHONE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `employe`
--

INSERT INTO `employe` (`MATRICULE_EMPLOYE`, `NOM`, `PRENOM`, `QUALIFICATION`, `ADRESSE`, `TELEPHONE`, `SEXE`, `NATIONALITE`, `FONCTION`, `PHOTO`) VALUES
(1, 'MANIMPA', 'Jean', 'Sans', 'Cibitoke', '+257 79 711 987', 'Masculin', 'Burundais', 'Nettoyeur', 'DSC00312.JPG'),
(3, 'NZANZABAGENZI', 'Marie', 'LicenciÃ©', 'Cibitoke', '+257 79 719 783', 'Masculin', 'Burundais', 'maitre', 'DSC05931.JPG'),
(12, 'NSABIMANA', 'Marie', 'A1', 'Cibitoke', '+257 79 719 789', 'Masculin', 'Burundais', 'maitre', '3.jpg'),
(122, 'NZEYIMANA', 'Jean', 'LicenciÃ©', 'Cibitoke', '+257 79 719 780', 'Masculin', 'Burundais', 'maitre', 'DSC05928.JPG'),
(222, 'KARORERE', 'MARS', 'A2', 'KABONDO', '+257 75 234373', 'Masculin', 'Burundais', 'maitre', '4.jpg'),
(777, 'Minani', 'Paul', 'A2', 'KINANIRA', '+257 79 758 412', 'Masculin', 'Burundais', 'Maitre nageur', 'P8241515.JPG'),
(2222, 'KAMIKAZI', 'MONIQUE', 'Licence', 'KABONDO', '+257 75 437865', 'Feminin', 'Burundais', 'Secretaire', '1.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE IF NOT EXISTS `inscription` (
  `ID_INSCRIPTION` int(11) NOT NULL AUTO_INCREMENT,
  `ID_SECTION` int(11) NOT NULL,
  `MATRICULE` int(11) NOT NULL,
  `DATE_INSCRIPTION` date NOT NULL,
  PRIMARY KEY (`ID_INSCRIPTION`),
  KEY `ID_SECTION` (`ID_SECTION`),
  KEY `MATRICULE` (`MATRICULE`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=102 ;

--
-- Contenu de la table `inscription`
--

INSERT INTO `inscription` (`ID_INSCRIPTION`, `ID_SECTION`, `MATRICULE`, `DATE_INSCRIPTION`) VALUES
(66, 1, 2, '2015-09-02'),
(67, 1, 3, '2015-03-03'),
(68, 1, 4, '2015-09-08'),
(69, 1, 5, '2015-01-01'),
(70, 1, 6, '2015-02-01'),
(71, 1, 7, '2015-02-01'),
(72, 1, 8, '2015-03-01'),
(73, 1, 9, '2014-03-05'),
(74, 1, 12, '2015-04-15'),
(75, 1, 13, '2015-04-15'),
(76, 1, 145, '2015-04-15'),
(77, 1, 146, '2014-04-09'),
(78, 1, 141, '2015-04-15'),
(80, 1, 11, '2013-04-16'),
(81, 1, 135, '2013-04-16'),
(82, 1, 35, '2013-04-16'),
(83, 1, 351, '2013-04-16'),
(84, 1, 3521, '2014-04-16'),
(85, 1, 39, '2013-04-16'),
(86, 1, 14, '2013-04-16'),
(87, 1, 15, '2013-04-16'),
(88, 1, 16, '2013-04-16'),
(89, 1, 17, '2013-04-16'),
(90, 1, 18, '2014-04-09'),
(91, 1, 158, '2015-04-22'),
(92, 1, 234, '2015-04-22'),
(93, 1, 221, '2015-04-22'),
(94, 1, 19, '2015-06-02'),
(99, 1, 21, '2015-06-02'),
(100, 1, 22111, '2015-06-15');

-- --------------------------------------------------------

--
-- Structure de la table `paie`
--

CREATE TABLE IF NOT EXISTS `paie` (
  `ID_PAIE` int(11) NOT NULL AUTO_INCREMENT,
  `MATRICULE` int(11) NOT NULL,
  `ID_ABONNEMENT` int(11) NOT NULL,
  `DATE_DEBUT` date DEFAULT NULL,
  `DATE_FIN` date DEFAULT NULL,
  PRIMARY KEY (`ID_PAIE`),
  KEY `MATRICULE` (`MATRICULE`),
  KEY `ID_ABONNEMENT` (`ID_ABONNEMENT`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=84 ;

--
-- Contenu de la table `paie`
--

INSERT INTO `paie` (`ID_PAIE`, `MATRICULE`, `ID_ABONNEMENT`, `DATE_DEBUT`, `DATE_FIN`) VALUES
(48, 2, 2, '2015-04-13', '2015-05-13'),
(49, 3, 2, '2015-04-13', '2015-05-13'),
(50, 4, 2, '2015-04-13', '2015-05-13'),
(51, 5, 2, '2015-04-13', '2015-05-13'),
(52, 6, 2, '2015-04-13', '2015-05-13'),
(53, 7, 2, '2015-06-07', '2015-07-07'),
(54, 8, 8, '2014-04-13', '2015-04-13'),
(55, 9, 8, '2015-04-13', '2016-04-13'),
(56, 12, 3, '2015-04-15', '2015-07-15'),
(57, 13, 5, '2015-04-15', '2015-10-15'),
(58, 145, 5, '2015-04-23', '2015-10-23'),
(59, 146, 5, '2015-04-02', '2015-10-02'),
(60, 141, 8, '2015-04-15', '2016-04-15'),
(62, 11, 8, '2012-04-02', '2013-04-02'),
(63, 135, 7, '2013-04-02', '2014-04-02'),
(64, 35, 8, '2014-04-02', '2015-04-02'),
(65, 351, 1, '2013-04-02', '2013-05-02'),
(66, 3521, 2, '2013-04-02', '2013-05-02'),
(67, 39, 4, '2013-04-02', '2013-07-02'),
(68, 14, 4, '2013-04-02', '2013-07-02'),
(69, 15, 6, '2013-04-02', '2013-10-02'),
(70, 16, 4, '2015-04-24', '2015-07-24'),
(71, 17, 5, '2013-04-02', '2013-10-02'),
(72, 18, 7, '2013-04-02', '2014-04-02'),
(73, 158, 3, '2015-04-22', '2015-07-22'),
(74, 234, 3, '2015-04-23', '2015-07-23'),
(75, 221, 4, '2015-04-22', '2015-07-22'),
(76, 19, 2, '2015-04-13', '2015-05-13'),
(81, 21, 2, '2015-04-13', '2015-05-13'),
(82, 22111, 1, '2015-06-15', '2015-07-15');

-- --------------------------------------------------------

--
-- Structure de la table `participe`
--

CREATE TABLE IF NOT EXISTS `participe` (
  `ID_PARTICIPE` int(11) NOT NULL AUTO_INCREMENT,
  `MATRICULE` int(11) NOT NULL,
  `ID_TOURNOIS` int(11) NOT NULL,
  `DATE_TOURNOIS` date NOT NULL,
  `SCORE` int(11) NOT NULL,
  PRIMARY KEY (`ID_PARTICIPE`),
  KEY `ID_TOURNOIS` (`ID_TOURNOIS`),
  KEY `MATRICULE` (`MATRICULE`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Contenu de la table `participe`
--

INSERT INTO `participe` (`ID_PARTICIPE`, `MATRICULE`, `ID_TOURNOIS`, `DATE_TOURNOIS`, `SCORE`) VALUES
(11, 2, 2, '2015-03-04', 4),
(13, 4, 3, '2015-03-16', 1),
(14, 141, 1, '2013-04-16', 4),
(15, 2, 1, '2013-04-11', 4),
(16, 12, 1, '2013-04-16', 1),
(17, 13, 1, '2013-04-16', 2),
(18, 17, 1, '2013-04-16', 3),
(19, 351, 1, '2013-04-16', 3),
(20, 146, 1, '2013-04-16', 2),
(21, 3, 2, '2013-04-10', 2),
(22, 4, 2, '2013-04-16', 4),
(23, 14, 3, '2015-04-22', 2),
(24, 135, 1, '2015-04-01', 3),
(25, 12, 1, '2015-05-06', 2),
(26, 13, 1, '2015-05-06', 2),
(27, 19, 2, '2015-05-06', 3),
(28, 3, 3, '2015-05-06', 2),
(30, 39, 3, '2015-05-06', 3);

-- --------------------------------------------------------

--
-- Structure de la table `receptioniste`
--

CREATE TABLE IF NOT EXISTS `receptioniste` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(40) CHARACTER SET latin1 NOT NULL,
  `PASSWORD` varchar(40) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `receptioniste`
--

INSERT INTO `receptioniste` (`id`, `NAME`, `PASSWORD`) VALUES
(1, 'mami', '1234');

-- --------------------------------------------------------

--
-- Structure de la table `section`
--

CREATE TABLE IF NOT EXISTS `section` (
  `ID_SECTION` int(11) NOT NULL,
  `LIBELLE` varchar(25) NOT NULL,
  PRIMARY KEY (`ID_SECTION`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `section`
--

INSERT INTO `section` (`ID_SECTION`, `LIBELLE`) VALUES
(1, 'Piscine');

-- --------------------------------------------------------

--
-- Structure de la table `tournois`
--

CREATE TABLE IF NOT EXISTS `tournois` (
  `ID_TOURNOIS` int(11) NOT NULL AUTO_INCREMENT,
  `LIBELLE` varchar(15) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID_TOURNOIS`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `tournois`
--

INSERT INTO `tournois` (`ID_TOURNOIS`, `LIBELLE`) VALUES
(1, 'Petit'),
(2, 'Moyen'),
(3, 'Grand');

-- --------------------------------------------------------

--
-- Structure de la table `travaille`
--

CREATE TABLE IF NOT EXISTS `travaille` (
  `ID_TRAVAIL` int(11) NOT NULL AUTO_INCREMENT,
  `ID_SECTION` int(11) NOT NULL,
  `MATRICULE_EMPLOYE` int(11) NOT NULL,
  `DATE_EMBAUCHE` date NOT NULL,
  PRIMARY KEY (`ID_TRAVAIL`),
  KEY `MATRICULE_EMPLOYE` (`MATRICULE_EMPLOYE`),
  KEY `ID_SECTION` (`ID_SECTION`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `travaille`
--

INSERT INTO `travaille` (`ID_TRAVAIL`, `ID_SECTION`, `MATRICULE_EMPLOYE`, `DATE_EMBAUCHE`) VALUES
(1, 1, 12, '2015-03-10'),
(2, 1, 122, '2015-03-03'),
(3, 1, 3, '2015-03-03'),
(4, 1, 1, '2015-03-19'),
(5, 1, 2222, '2015-08-02'),
(6, 1, 222, '2015-08-01'),
(10, 1, 777, '2015-06-03');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(40) CHARACTER SET latin1 NOT NULL,
  `PASSWORD` varchar(40) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`ID`, `NAME`, `PASSWORD`) VALUES
(1, 'willy', '123'),
(2, 'arlene', '321');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID` int(10) NOT NULL,
  `NOM` varchar(25) CHARACTER SET latin1 NOT NULL,
  `PRENOM` varchar(25) CHARACTER SET latin1 NOT NULL,
  `EMAIL` varchar(25) CHARACTER SET latin1 NOT NULL,
  `TELEPHONE` int(15) NOT NULL,
  `QUALIFICATION` varchar(20) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `utilisateur`
--


--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD CONSTRAINT `inscription_ibfk_1` FOREIGN KEY (`ID_SECTION`) REFERENCES `section` (`ID_SECTION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inscription_ibfk_2` FOREIGN KEY (`MATRICULE`) REFERENCES `client` (`MATRICULE`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `paie`
--
ALTER TABLE `paie`
  ADD CONSTRAINT `paie_ibfk_2` FOREIGN KEY (`ID_ABONNEMENT`) REFERENCES `abonnement` (`ID_ABONNEMENT`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `paie_ibfk_3` FOREIGN KEY (`MATRICULE`) REFERENCES `client` (`MATRICULE`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `participe`
--
ALTER TABLE `participe`
  ADD CONSTRAINT `participe_ibfk_1` FOREIGN KEY (`MATRICULE`) REFERENCES `client` (`MATRICULE`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `participe_ibfk_2` FOREIGN KEY (`ID_TOURNOIS`) REFERENCES `tournois` (`ID_TOURNOIS`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `travaille`
--
ALTER TABLE `travaille`
  ADD CONSTRAINT `travaille_ibfk_1` FOREIGN KEY (`ID_SECTION`) REFERENCES `section` (`ID_SECTION`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `travaille_ibfk_2` FOREIGN KEY (`MATRICULE_EMPLOYE`) REFERENCES `employe` (`MATRICULE_EMPLOYE`) ON DELETE CASCADE ON UPDATE CASCADE;
